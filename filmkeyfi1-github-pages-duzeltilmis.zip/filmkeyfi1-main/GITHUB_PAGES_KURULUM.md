# FILMKEYFİ — GitHub Pages kurulumu

Bu proje GitHub Pages için düzenlenmiştir. Frontend GitHub Pages'te çalışır; Base44 veritabanı ve server functions ise Base44 tarafında kalır.

## 1) GitHub Secrets ekle

Repository → **Settings → Secrets and variables → Actions → New repository secret** bölümünden:

- `BASE44_APP_ID` = Base44 uygulamanın App ID'si
- `BASE44_APP_BASE_URL` = Base44 uygulamanın yayın URL'si (ör. `https://...base44.app`)
- `BASE44_FUNCTIONS_VERSION` = gerekiyorsa Base44 Functions sürümü

App ID ve URL'yi Base44 projenin Git/Environment ayarlarından al.

## 2) GitHub Pages

Repository → Settings → Pages → Source kısmında **GitHub Actions** seç.

`main` branch'e push yaptığında workflow otomatik build/deploy eder.

## 3) Önemli

GitHub Pages sadece frontend'i barındırır. Base44 entity'leri, authentication ve server functions için Base44 backend erişilebilir olmalıdır.

Custom domain kullanıyorsan `vite.config.js` içindeki default repository base'i yerine workflow'da `VITE_BASE_PATH=/` ayarla.
