import { useEffect, useState, useRef } from 'react';
import { Outlet, NavLink, useNavigate, Link } from 'react-router-dom';
import { useCurrentUser } from '@/lib/useCurrentUser';
import { LayoutDashboard, UserCheck, Users, Film, FolderTree, DoorOpen, MessageSquare, LifeBuoy, Package, CreditCard, RefreshCw, Bell, BarChart3, Settings, LogOut, Menu, X, ShieldAlert, KeyRound } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAdminNotifications, requestNotificationPermission } from '@/hooks/useAdminNotifications';

const nav = [
  { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/kayit', label: 'Kayıt Kontrol', icon: UserCheck },
  { to: '/admin/kullanicilar', label: 'Kullanıcılar', icon: Users },
  { to: '/admin/filmler', label: 'Filmler', icon: Film },
  { to: '/admin/film-ekle', label: 'Film Yükle', icon: Film },
  { to: '/admin/kategoriler', label: 'Kategoriler', icon: FolderTree },
  { to: '/admin/odalar', label: 'Odalar', icon: DoorOpen },
  { to: '/admin/oda-mesajlari', label: 'Oda Mesajları', icon: MessageSquare },
  { to: '/admin/destek', label: 'Destek Mesajları', icon: LifeBuoy },
  { to: '/admin/paketler', label: 'Paketler', icon: Package },
  { to: '/admin/odemeler', label: 'Ödemeler', icon: CreditCard },
  { to: '/admin/yenilemeler', label: 'Yenileme Talepleri', icon: RefreshCw },
  { to: '/admin/bildirimler', label: 'Bildirimler', icon: Bell },
  { to: '/admin/guvenlik', label: 'Güvenlik', icon: ShieldAlert },
  { to: '/admin/raporlar', label: 'Raporlar', icon: BarChart3 },
  { to: '/admin/ayalar', label: 'Ayarlar', icon: Settings },
];

export default function AdminLayout() {
  const { user, loading } = useCurrentUser();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const touchX = useRef(null);
  const [twofaOk, setTwofaOk] = useState(() => sessionStorage.getItem('admin2fa') === 'ok');
  const [twofaCode, setTwofaCode] = useState('');
  const [twofaErr, setTwofaErr] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [notifGranted, setNotifGranted] = useState(() => typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted');
  useAdminNotifications();
  const handleNotif = async () => { const r = await requestNotificationPermission(); setNotifGranted(r === 'granted'); };

  useEffect(() => {
    if (!loading && (!user || user.role !== 'admin')) navigate('/');
  }, [user, loading]);

  if (loading) return <div className="h-screen flex items-center justify-center"><div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" /></div>;
  if (!user || user.role !== 'admin') return null;

  const verify2fa = async () => {
    setVerifying(true); setTwofaErr('');
    try {
      const res = await base44.functions.invoke('admin-2fa', { action: 'verify', code: twofaCode });
      if (res.data.verified) { sessionStorage.setItem('admin2fa', 'ok'); setTwofaOk(true); }
      else setTwofaErr('Hatalı kod');
    } catch (e) { setTwofaErr(e.response?.data?.error || 'Hatalı kod'); }
    setVerifying(false);
  };

  if (user.twofa_enabled && !twofaOk) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="bg-card border border-border rounded-xl p-6 w-full max-w-sm">
          <div className="flex items-center gap-2 mb-3"><KeyRound className="w-5 h-5 text-primary" /><h1 className="text-lg font-bold">Admin 2FA Doğrulama</h1></div>
          <p className="text-sm text-muted-foreground mb-4">Admin paneline erişim için authenticator kodunuzu girin.</p>
          <input value={twofaCode} onChange={(e) => setTwofaCode(e.target.value)} maxLength={6} placeholder="6 haneli kod" className="w-full bg-secondary/60 rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring mb-2" />
          {twofaErr && <p className="text-xs text-destructive mb-2">{twofaErr}</p>}
          <button onClick={verify2fa} disabled={verifying || twofaCode.length !== 6} className="w-full bg-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold disabled:opacity-50">{verifying ? 'Doğrulanıyor...' : 'Doğrula'}</button>
          <button onClick={() => base44.auth.logout('/login')} className="w-full mt-2 text-sm text-muted-foreground py-2">Çıkış</button>
        </div>
      </div>
    );
  }

  const logout = () => { sessionStorage.removeItem('admin2fa'); base44.auth.logout('/login'); };

  return (
    <div className="min-h-screen bg-background flex">
      <aside className={`fixed lg:sticky top-0 z-40 h-screen w-64 bg-sidebar border-r border-sidebar-border flex flex-col transition-transform ${open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-4 flex items-center justify-between">
          <Link to="/admin" className="text-lg font-extrabold"><span className="text-gradient">FILM</span>KEYFİ <span className="text-xs text-muted-foreground font-normal">Admin</span></Link>
          <button onClick={() => setOpen(false)} className="lg:hidden p-1"><X className="w-5 h-5" /></button>
        </div>
        <nav className="flex-1 overflow-y-auto px-2 space-y-0.5">
          {nav.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} onClick={() => setOpen(false)}
              className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${isActive ? 'bg-sidebar-primary text-sidebar-primary-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent'}`}>
              <n.icon className="w-4 h-4" /> {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-3 border-t border-sidebar-border">
          <Link to="/" className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-sidebar-foreground hover:bg-sidebar-accent">Siteye Dön</Link>
          <button onClick={logout} className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-destructive hover:bg-sidebar-accent"><LogOut className="w-4 h-4" /> Çıkış</button>
        </div>
      </aside>
      {open && <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setOpen(false)} />}
      <div className="flex-1 min-w-0">
        <header className="lg:hidden sticky top-0 z-20 glass border-b border-border h-14 flex items-center px-4"
          onTouchStart={(e) => { touchX.current = e.touches[0].clientX; }}
          onTouchEnd={(e) => { const dx = e.changedTouches[0].clientX - (touchX.current ?? 0); if (Math.abs(dx) > 55) setOpen((v) => !v); }}>
          <button onClick={() => setOpen(true)}><Menu className="w-6 h-6" /></button>
          <span className="ml-3 font-bold">Admin Panel</span>
          <button onClick={handleNotif} className="ml-auto p-2 rounded-lg hover:bg-secondary relative shrink-0" title="Bildirimleri Aç">
            <Bell className="w-5 h-5" />
            {notifGranted && <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-green-500" />}
          </button>
        </header>
        <div className="p-4 sm:p-6">
          <Outlet />
        </div>
      </div>
    </div>
  );
}