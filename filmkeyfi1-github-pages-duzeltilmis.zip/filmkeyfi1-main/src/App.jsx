import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
// Add page imports here
import AppLayout from '@/components/layout/AppLayout';
import Home from '@/pages/Home';
import Browse from '@/pages/Browse';
import MovieDetail from '@/pages/MovieDetail';
import Watch from '@/pages/Watch';
import WatchParty from '@/pages/WatchParty';
import CreateRoom from '@/pages/CreateRoom';
import Profile from '@/pages/Profile';
import MyList from '@/pages/MyList';
import Search from '@/pages/Search';
import Support from '@/pages/Support';
import Notifications from '@/pages/Notifications';
import AdminLayout from '@/pages/admin/AdminLayout';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import AdminUsers from '@/pages/admin/AdminUsers';
import AdminMovies from '@/pages/admin/AdminMovies';
import AdminRooms from '@/pages/admin/AdminRooms';
import AdminRoomMessages from '@/pages/admin/AdminRoomMessages';
import AdminSupport from '@/pages/admin/AdminSupport';
import AdminPackages from '@/pages/admin/AdminPackages';
import AdminRenewals from '@/pages/admin/AdminRenewals';
import AdminNotifications from '@/pages/admin/AdminNotifications';
import AdminCategories from '@/pages/admin/AdminCategories';
import OpenRooms from '@/pages/OpenRooms';
import AdminReports from '@/pages/admin/AdminReports';
import AdminSecurity from '@/pages/admin/AdminSecurity';
import UserProfile from '@/pages/UserProfile';
import { Navigate } from 'react-router-dom';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import PendingApproval from '@/pages/PendingApproval';
import SecurityProtocol from '@/pages/SecurityProtocol';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'unknown' && String(authError.message || '').includes('Base44 bağlantısı yapılandırılmamış')) {
      return (
        <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-6">
          <div className="max-w-xl w-full rounded-2xl border border-slate-800 bg-slate-900 p-6 shadow-xl">
            <h1 className="text-2xl font-bold mb-3">Base44 bağlantısı yapılandırılmamış</h1>
            <p className="text-slate-300 mb-4">GitHub Actions Secrets bölümüne BASE44_APP_ID ve BASE44_APP_BASE_URL değerlerini ekleyip main branch'e yeniden gönderin.</p>
            <code className="block rounded-lg bg-slate-950 p-4 text-sm text-slate-300">Settings → Secrets and variables → Actions</code>
          </div>
        </div>
      );
    }
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/onay-bekleniyor" element={<PendingApproval />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<AppLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/filmler" element={<Browse type="movie" title="Filmler" />} />
          <Route path="/acik-odalar" element={<OpenRooms />} />
          <Route path="/kategoriler" element={<Browse type="movie" title="Kategoriler" />} />
          <Route path="/izle/:id" element={<MovieDetail />} />
          <Route path="/video/:id" element={<Watch />} />
          <Route path="/oda/:id" element={<WatchParty />} />
          <Route path="/oda-kur" element={<CreateRoom />} />
          <Route path="/listem" element={<MyList />} />
          <Route path="/ara" element={<Search />} />
          <Route path="/destek" element={<Support />} />
          <Route path="/bildirimler" element={<Notifications />} />
          <Route path="/profil" element={<Profile />} />
          <Route path="/kullanici/:id" element={<UserProfile />} />
          <Route path="/güvenlik-protokolü" element={<SecurityProtocol />} />
        </Route>
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<AdminDashboard />} />
          <Route path="kayit" element={<AdminUsers pendingOnly />} />
          <Route path="kullanicilar" element={<AdminUsers />} />
          <Route path="filmler" element={<AdminMovies />} />
          <Route path="film-ekle" element={<AdminMovies />} />
          <Route path="kategoriler" element={<AdminCategories />} />
          <Route path="odalar" element={<AdminRooms />} />
          <Route path="oda-mesajlari" element={<AdminRoomMessages />} />
          <Route path="destek" element={<AdminSupport />} />
          <Route path="paketler" element={<AdminPackages />} />
          <Route path="odemeler" element={<AdminReports />} />
          <Route path="yenilemeler" element={<AdminRenewals />} />
          <Route path="bildirimler" element={<AdminNotifications />} />
          <Route path="raporlar" element={<AdminReports />} />
          <Route path="guvenlik" element={<AdminSecurity />} />
          <Route path="ayalar" element={<AdminDashboard />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App