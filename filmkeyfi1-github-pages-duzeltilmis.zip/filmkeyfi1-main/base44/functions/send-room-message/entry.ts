import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { sanitizeText, rateLimit, safeErrorResponse, logSecurity } from '../../shared/security.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const body = await req.json();
    const { room_id, text } = body || {};
    if (!room_id || !text || typeof text !== 'string') {
      return Response.json({ error: 'invalid' }, { status: 400 });
    }
    if (text.length > 1000) return Response.json({ error: 'mesaj çok uzun' }, { status: 400 });

    // IDOR koruması: kullanıcının oda katılımcısı olduğunu doğrula
    const room = await base44.asServiceRole.entities.Room.get(room_id).catch(() => null);
    if (!room) return Response.json({ error: 'oda bulunamadı' }, { status: 404 });
    const me = await base44.asServiceRole.entities.User.get(user.id);
    const isMod = me.role === 'admin' || me.role === 'moderator';
    const isOwner = room.owner_id === user.id;
    const isParticipant = (room.participants || []).some((p) => p.user_id === user.id);
    if (!isParticipant && !isOwner && !isMod) {
      await logSecurity(base44, 'room_msg_denied', user, 'not participant: ' + room_id, 'warning');
      return Response.json({ error: 'bu odada mesaj gönderemezsiniz' }, { status: 403 });
    }

    // Sohbet kapalıysa sadece admin/moderator mesaj gönderebilir
    if (!room.chat_enabled && !isMod) {
      return Response.json({ error: 'sohbet kapalı' }, { status: 403 });
    }

    // Rate limit: 15 mesaj / 30 saniye / kullanıcı
    const key = 'chat:' + user.id;
    const rl = await rateLimit(base44, key, user.id, 15, 30000);
    if (!rl.allowed) {
      return Response.json({ error: 'çok hızlı mesaj gönderiyorsunuz' }, { status: 429 });
    }

    // XSS sanitizasyonu
    const clean = sanitizeText(text, 1000);
    if (!clean) return Response.json({ error: 'boş mesaj' }, { status: 400 });
    const name = user.username || user.full_name || 'Kullanıcı';
    await base44.asServiceRole.entities.RoomMessage.create({
      room_id, user_id: user.id, user_name: name, user_avatar: user.avatar || '',
      text: clean, type: 'user'
    });
    return Response.json({ ok: true });
  } catch (e) {
    return safeErrorResponse(e);
  }
}