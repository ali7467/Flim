import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'
import path from 'path'

// GitHub Pages uses /<repository>/ by default. Set VITE_BASE_PATH='/'
// when using a custom domain or a user/organization Pages site.
const base = process.env.VITE_BASE_PATH || '/filmkeyfi1/'

export default defineConfig({
  base,
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(process.cwd(), './src'),
    },
  },
})
